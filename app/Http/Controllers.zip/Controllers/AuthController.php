<?php
  
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Validator;
use Hash;
use Session;
use App\Models\Admin;
use DB;


  
  
class AuthController extends Controller
{
    // public function index()
    // {
    //     // return view('Halo');
    //     $admin = DB::table('admin')->get();
    // 	return view('admin.admin',compact('admin'));
    // }

    public function login()
    {
        return view('login');
    }

    public function AuthCheck(Request $request) 
    {

        $email = $request->email;
    	$password = $request->password;
        $user_hashed_pass = Hash::make($password);
        
        $login_sequence = DB::table('admin')->where('email',$email)->first();
        if ($login_sequence) {
            if ($login_sequence->status==0) {
                $verify_password = Hash::check($password,$login_sequence->password);
                if ($verify_password) {
                    return back()->withInput()->with('fail','Maaf akun Anda sedang disuspend oleh Superadmin!');
                }
                else{
                    return back()->withInput()->with('fail','Email atau password mungkin tidak cocok');
                }
            }
            else{
                $verify_password = Hash::check($password,$login_sequence->password);
                if ($verify_password) {
                    $login_result = DB::table('admin')->where('email',$email)->first();
                    Session::put('admin_id',$login_result->admin_id);
                    // Session::put('part_id',$login_result->admin_id);
                    Session::put('name',$login_result->name);
                    Session::put('email',$login_result->email);
                    // Session::put('image',$login_result->AdminImage);
                    Session::put('level',$login_result->level);
                    // Session::put('userlevel',"admin");
                    // Session::put('admin','1');
                    Session::put('login',TRUE);
                    return redirect()->route('dashboard')->with('Success','Login Berhasil');
                   
                }
                else{
                    return back()->withInput()->with('fail','Email atau password mungkin tidak cocok');
                }
            }
        }else{
           return back()->withInput()->with('fail','Email atau password mungkin tidak cocok');
        }

    }


    public function logout(Request $request){
    	$request->Session()->flush();
    	return redirect()->route('login');
    }



    // public function admin_store(Request $request)
    // {
    
    //     $store = DB::table('admin')
    //     ->insert([
    //         'email'     =>  $request->email,
    //         'password'  =>  Hash::make('12345678'),
    //         'name'      => $request->admin_name,
    //         'admin_id'  => Str::random(6),
           
    //     ]);

    //     if ($store) {
            
    //         return redirect()->route('data_admin')->with(['success' => 'Data Berhasil Disimpan!']);
        
    //     }

    // }


    

    // public function admin_non_aktif(Request $request)
    // {
    //     $non_aktif = DB::table('admin')
    //     ->where(
    //         'id',$request->id_admin,
    //     )
    //     ->update([
    //         'status'=>'0',
    //     ]);
    // }

    // public function admin_aktif(Request $request)
    // {
    //     $aktif = DB::table('admin')
    //     ->where(
    //         'id',$request->id_admin,
    //     )
    //     ->update([
    //         'status'=>'1',
    //     ]);
    // }
    


    // public function delete_admin(Request $request)
    // {
    //     $del_admin = \DB::table('admin')
    //     ->where(
    //         'id',$request->id_admin)->delete();

    //     $admin = DB::table('admin')->get();
    //     return view('admin.tabel_admin', compact('admin'));

    // }


    // public function profile_admin($id)
    // {
    //     $profile = DB::table('admin')
    //     ->where('admin_id',$id)
    //     ->get();
    // 	return view('admin.profile',compact('profile'));
    // }




    // public function changePassword(Request $request){

    // 	$password_old = $request->password_old;
    //     $pass = Hash::make($password_old);
            
    //     $cek = DB::table('admin')->where('admin_id',$request->id)->first();
    //     // $verify_password lama
    //     if (!(Hash::check($password_old,$cek->password))) {
    //         return redirect()->back()->with("error","Kata sandi Anda saat ini tidak cocok dengan kata sandi yang Anda berikan. Silakan coba lagi.");
    //     }
       
    //     if(strcmp($request->password_old, $request->new_password) == 0) {
    //         //password baru
    //         return redirect()->back()->with("error","Kata Sandi Baru tidak boleh sama dengan kata sandi Anda saat ini. Silakan pilih kata sandi yang berbeda.");
    //     }

    //     if(!(strcmp($request->new_password, $request->new_password_confirm)) == 0) {
    //         //konfirmasi password baru
    //         return redirect()->back()->with("error","Kata Sandi Baru harus sama dengan kata sandi Anda yang telah dikonfirmasi. Silakan ketik ulang kata sandi baru.");
    //     }
        
    //     DB::table('admin')->where('admin_id',$request->id)->update([
    //         'password' => Hash::make($request->new_password),  
    //     ]);

    //     return redirect()->back()->with("success","Password berhasil diubah !");
         
    // }


    // public function update_profil(Request $request, $id)
    // {
    //     // update data pegawai
	// DB::table('admin')->where('id',$request->id)->update([
	// 	'name' => $request->name,
	// 	'email' => $request->email,
	// ]);
	// // alihkan halaman ke halaman pegawai
	// return back();
    // }


    public function lupa_password(Request $request)
    {
        
	return view('lupa_password');
    }


  
}