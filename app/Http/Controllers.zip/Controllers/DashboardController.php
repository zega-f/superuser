<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;
use DB;

class DashboardController extends Controller
{
    function __construct()
    {
        $this->middleware('admin');
    }
    
    public function index()
    {
        // $kls = DB::table('kelas')->get();
    	return view('dashboard');
    }

}
