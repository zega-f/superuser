<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Validator;
use Hash;
use Session;
use App\Models\Admin;
use DB;

class AdminController extends Controller
{
    
    function __construct()
    {
        $this->middleware('admin');
    }

    public function index()
    {
        $admin = DB::table('admin')->get();
    	return view('admin.admin',compact('admin'));
    }

    
    public function admin_store(Request $request)
    {
        $store = DB::table('admin')
        ->insert([
            'email'     =>  $request->email,
            'password'  =>  Hash::make('12345678'),
            'name'      => $request->admin_name,
            'admin_id'  => Str::random(6),           
        ]);

        if ($store) {
            return redirect()->route('data_admin')->with(['success' => 'Data Berhasil Disimpan!']);
        }
    }


    public function reset_password(Request $request, $id)
    {
        
	DB::table('admin')->where('id',$request->id)->update([
		'password' => Hash::make('1234'),
	]);
	return back();
    }


    public function admin_non_aktif(Request $request)
    {
        $non_aktif = DB::table('admin')
        ->where(
            'id',$request->id_admin,
        )
        ->update([
            'status'=>'0',
        ]);
    }

    public function admin_aktif(Request $request)
    {
        $aktif = DB::table('admin')
        ->where(
            'id',$request->id_admin,
        )
        ->update([
            'status'=>'1',
        ]);
    }
    


    public function delete_admin(Request $request)
    {
        $del_admin = \DB::table('admin')
        ->where(
            'id',$request->id_admin)->delete();

        $admin = DB::table('admin')->get();
        return view('admin.tabel_admin', compact('admin'));

    }


    public function profile_admin($id)
    {
        $profile = DB::table('admin')
        ->where('admin_id',$id)
        ->get();
    	return view('admin.profile',compact('profile'));
    }


    public function changePassword(Request $request){

    	$password_old = $request->password_old;
        $pass = Hash::make($password_old);
            
        $cek = DB::table('admin')->where('admin_id',$request->id)->first();
        // $verify_password lama
        if (!(Hash::check($password_old,$cek->password))) {
            return redirect()->back()->with("error","Kata sandi Anda saat ini tidak cocok dengan kata sandi yang Anda berikan. Silakan coba lagi.");
        }
       
        if(strcmp($request->password_old, $request->new_password) == 0) {
            //password baru
            return redirect()->back()->with("error","Kata Sandi Baru tidak boleh sama dengan kata sandi Anda saat ini. Silakan pilih kata sandi yang berbeda.");
        }

        if(!(strcmp($request->new_password, $request->new_password_confirm)) == 0) {
            //konfirmasi password baru
            return redirect()->back()->with("error","Kata Sandi Baru harus sama dengan kata sandi Anda yang telah dikonfirmasi. Silakan ketik ulang kata sandi baru.");
        }
        
        DB::table('admin')->where('admin_id',$request->id)->update([
            'password' => Hash::make($request->new_password),  
        ]);

        return redirect()->back()->with("success","Password berhasil diubah !");
         
    }


    public function update_profil(Request $request, $id)
    {
        // update data pegawai
	DB::table('admin')->where('id',$request->id)->update([
		'name' => $request->name,
		'email' => $request->email,
	]);
	// alihkan halaman ke halaman pegawai
	return back();
    }


}
