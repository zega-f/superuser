<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<table border="0" cellpadding="0" cellspacing="0">
        <tr>
            <td>
                <table border="0" cellpadding="0" cellspacing="0">
                    <tbody>
                    <tr>
                        <td align="left">
                            <table border="0" cellpadding="0" cellspacing="0">
                                <tbody>
                                <tr>
                                    <td> <div class="container">
                                            <center><p>Password Baru Anda :</p></center>
                                            <hr>
                                            <center><p>{{ $konten }}</p></center>
                                            <hr>
                                            <center><p>Masukkan Password diatas untuk Login</p></center>
                                            <hr>
                                            <center><p>Ubah password sesuai dengan kebutuhan Anda ketika telah berhasil masuk.</p></center>
                                        </div>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                    </tbody>
                </table>
                {{--<p>Good luck!</p>--}}
            </td>
        </tr>
    </table>	
</body>
</html>