@extends('layout.template')
@section('contens')

<br>
<section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="{{ url('kelas') }}">Kelas</a></li>
              <li class="breadcrumb-item active">Kelola Kelas</li>
            </ol>
          </div>
        {{-- <div class="col-sm-6 float-right">
          <h1>Profile</h1>
        </div> --}}
        
      </div>
    </div>
  </section>

<div class="row">



<div class="col-xl-6 col-lg-6 col-md-6">
    <div class="card mb-3 shadow-sm border-light">
        <div class="card-header" style="background-color: grey; font-size: 15px;">
            <strong style="color:white;">Data Pendaftar</strong>
            <strong style="color: white;">
                @foreach($nama_kelas as $k):
                {{-- @if($k->jenjang=='1')
                SD
                @elseif($k->jenjang=='2')      
                SMP
                @elseif($k->jenjang=='3')
                SMA
                @endif  
                {{ $k->room_name }} --}}
                Tingkat {{ $k->tingkat }}
                @endforeach
            </strong>
        </div>
        <div class="card-body" style="overflow: auto;">
              
            <div id="siswa_inaktif">
                @include('kelas.tabel_siswa_inactive')
            </div>
        </div>
    </div>
</div>
<div class="col-xl-6 col-lg-6 col-md-6">
    <div class="card mb-3 shadow-sm border-light">
        <div class="card-header bg-success"  style="font-size: 15px;">
            <strong style="color:white;">Data Siswa Aktif</strong>
            <strong>
                @foreach($nama_kelas as $k):
                @if($k->jenjang=='1')
                SD
                @elseif($k->jenjang=='2')      
                SMP
                @elseif($k->jenjang=='3')
                SMA
                @endif  
                Kelas {{ $k->tingkat }}{{ $k->room_name }}
                @endforeach
            </strong>
        </div>
        <div class="card-body" style="overflow: auto;">
            <div id="siswa_aktif">
                @include('kelas.tabel_siswa_active')
            </div>
        </div>
    </div>
</div>
</div>


<br>
<div class="col-xl-12 col-lg-12 col-md-12">
    <div class="card mb-3 shadow-sm border-light">
        <div class="card-header bg-info">
            <strong style="color:white; font-size:15px;">Jadwal Mapel</strong>
            <strong>
                @foreach($nama_kelas as $k):
                @if($k->jenjang=='1')
                SD
                @elseif($k->jenjang=='2')      
                SMP
                @elseif($k->jenjang=='3')
                SMA
                @endif  
                Kelas {{ $k->tingkat }}{{ $k->room_name }}
                @endforeach
            </strong>
        </div>
        <div class="card-body" style="overflow: auto;">
            <button type="button" class="btn btn-primary float-left" style="padding:6px !important; font-size:14px !important;" data-toggle="modal" data-target="#modal-jadwal">
                Tambah Jadwal</button>
            <div class="table-responsive" id="jadwal">
                @include('kelas.tabel_jadwal')
            </div>
        </div>
    </div>
</div>






{{-- <div class="modal fade" id="modal-default">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Tambah Mapel Kelas</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body">
                <form action="{{ url('mapelkelas_store') }}" method="POST">
                @csrf
                <div class="form-group">
                    <input type="hidden" name="id" value="<?php echo Request::segment(2);?>">

                    <?php $mapel = DB::table('tblmapel')
                    ->where('aktif','1')
                    ->get();?>
                    <select name="mapel_name" id="" class="form-control">
                        <option value="0">-Pilih Mapel-</option>
                        @foreach($mapel as $row)
                            <option value="{{ $row->id_mapel }}">{{ $row->nama }}</option>
                        @endforeach
                    </select><br>

                    <input type="number" name="harga" class="form-control" placeholder="harga mapel">
 
                </div>
                <button type="submit" class="btn btn-success">Simpan</button>
                </form>
            </div>
        </div>
      </div>
    </div>
</div> --}}



<div class="modal fade" id="modal-jadwal">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Tambah Jadwal Kelas</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">

            <form action="{{ url('jadwalkelas_store') }}" method="POST">
                @csrf
                <div class="card-body">
                  <div class="form-group">
                    <?php $segment = Request::segment(4)?>
                    <input type="hidden" name="id" value="<?php echo Request::segment(2);?>">
                    <input type="hidden" name="tingkat" value="<?php echo Request::segment(4);?>">
                    <?php $mapel = DB::table('mapel_kelas')
                    ->join('tblmapel', 'mapel_kelas.mapel', '=', 'tblmapel.id')
                    ->select('mapel_kelas.*', 'tblmapel.nama', 'tblmapel.id_mapel')
                    ->where('mapel_kelas.tingkat',$segment)
                    ->get();?>

                    <label>Mata Pelajaran</label>
                    <select name="mapel_name" id="mapel" class="form-control">
                        <option value="0">-Pilih Mapel-</option>
                        @foreach($mapel as $row)
                            <option value="{{ $row->id_mapel_kelas }}">{{ $row->nama }}</option>
                        @endforeach
                    </select><br>
                    
                    <label>Pengajar</label>
                    <select name="pengajar_name" guru="hari" class="form-control guru">
                        <option value="0">-Pilih Pengajar-</option>
                    </select><br>
                    
                      
                    <?php $hari = DB::table('tblhari')->get();?>
                    <label>Hari</label>
                    <select name="hari" id="hari" class="form-control">
                        <option value="0">-Pilih Hari-</option>
                        @foreach($hari as $row)
                            <option value="{{ $row->id }}">{{ ucfirst($row->namahari) }}</option>
                        @endforeach
                    </select><br>

                    <label>Jam</label>
                    <select name="jam" id="jam" class="form-control jam">
                        <option value="0">-Pilih jam-</option>
                    </select><br>
                    </div>
                  </div>
                  <button type="submit" class="btn btn-success">Simpan</button>
                </div>
            </form>
        </div>
       
      </div>
  <br><br> <br><br>

@endsection


<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>


{{-- ($setjam == '' ? 1 : @$data->nama+1)  --}}
    <script type="text/javascript">
        $(document).ready(function(){
            $('#mapel').change(function(){
                var id=$(this).val();
                // var kelas=$(this).attr('kelas');
                $.ajax({
                    url : "{{ url('change_guru') }}",
                    method : "get",
                    data : {id:id},
                    async : false,
                    dataType : 'json',
                    success: function(data){
                        console.log(data);
                        var html = '';
                        var i;
                        for(i=0; i<data.length; i++){
                            html += '<option value='+data[i].id_pengajar+'>' +(data[i]==null ? 'Kosong' : data[i].name)+ '</option>';
                        }
                        $('.guru').html(html);
                    }
                });
            });
        });
    </script>


    

    <script type="text/javascript">
        $(document).ready(function(){
            $('#hari').change(function(){
                var idh=$(this).val();
                // var id_guru = $(this).attr('id_guru');
                // var guru=$(this).val();
                $.ajax({
                    url : "{{ url('change_jam') }}",
                    method : "get",
                    data : {idh:idh, guru : $(".guru").val()},
                    async : false,
                    dataType : 'json',
                    success: function(data){
                        console.log(data);
                        var html = '';
                        var i;
                        for(i=0; i<data.length; i++){
                            html += '<option value='+data[i].id+'>Jam Ke-'+data[i].nama+' | '+data[i].start+' - '+data[i].end+'</option>';
                        }
                        $('.jam').html(html);
                         
                    }
                });
            });
        });
    </script>

  